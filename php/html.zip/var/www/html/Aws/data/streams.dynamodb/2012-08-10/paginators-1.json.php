<?php
// This file was auto-generated from sdk-root/src/data/streams.dynamodb/2012-08-10/paginators-1.json
return [ 'pagination' => [],];
