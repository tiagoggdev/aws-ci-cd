<?php
// This file was auto-generated from sdk-root/src/data/email/2010-12-01/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'ListIdentities', 'input' => [], 'errorExpectedFromService' => false, ], [ 'operationName' => 'VerifyEmailIdentity', 'input' => [ 'EmailAddress' => 'fake_email', ], 'errorExpectedFromService' => true, ], ],];
