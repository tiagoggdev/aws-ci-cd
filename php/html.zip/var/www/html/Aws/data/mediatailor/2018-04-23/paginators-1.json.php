<?php
// This file was auto-generated from sdk-root/src/data/mediatailor/2018-04-23/paginators-1.json
return [ 'pagination' => [],];
