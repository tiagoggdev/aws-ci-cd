from .extensions import db
from .models import Product, Sale
from decimal import Decimal
from datetime import datetime, timedelta
import random

def seed_data():
    if Product.query.count() == 0:
        productos = [
            Product(nombre="Leche Entera 1L", precio=Decimal("3.50"), stock=50, categoria="Lácteos", proveedor="Proveedor A"),
            Product(nombre="Huevos x30", precio=Decimal("12.00"), stock=8, categoria="Huevos", proveedor="Proveedor B"),
            Product(nombre="Arroz 1Kg", precio=Decimal("2.20"), stock=100, categoria="Granos", proveedor="Proveedor A"),
            Product(nombre="Aceite 900ml", precio=Decimal("4.80"), stock=5, categoria="Aceites", proveedor="Proveedor C"),
            Product(nombre="Pan Tajado", precio=Decimal("2.00"), stock=25, categoria="Panadería", proveedor="Proveedor D"),
        ]
        db.session.add_all(productos)
        db.session.commit()

    if Sale.query.count() == 0:
        products = Product.query.all()
        for _ in range(50):
            p = random.choice(products)
            cant = random.randint(1, 5)
            total = p.precio * cant
            fecha = datetime.utcnow() - timedelta(days=random.randint(0, 15))
            s = Sale(producto_id=p.id, cantidad=cant, total=total, fecha=fecha)
            db.session.add(s)
            p.stock = max(p.stock - cant, 0)
        db.session.commit()
