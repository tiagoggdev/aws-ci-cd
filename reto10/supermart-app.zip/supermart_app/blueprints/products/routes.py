from flask import Blueprint, render_template, request, redirect, url_for, flash
from decimal import Decimal, InvalidOperation
from ...extensions import db
from ...models import Product

bp = Blueprint("products", __name__)

@bp.route("/", methods=["GET"])
def list_products():
    categoria = request.args.get("categoria")
    proveedor = request.args.get("proveedor")
    q = request.args.get("q")

    query = Product.query
    if categoria:
        query = query.filter(Product.categoria.ilike(f"%{categoria}%"))
    if proveedor:
        query = query.filter(Product.proveedor.ilike(f"%{proveedor}%"))
    if q:
        query = query.filter(
            (Product.nombre.ilike(f"%{q}%")) |
            (Product.categoria.ilike(f"%{q}%")) |
            (Product.proveedor.ilike(f"%{q}%"))
        )

    products = query.order_by(Product.id.desc()).all()
    categorias = [c[0] for c in db.session.query(Product.categoria).distinct().all()]
    proveedores = [p[0] for p in db.session.query(Product.proveedor).distinct().all()]

    return render_template(
        "productos.html",
        products=products,
        categorias=categorias,
        proveedores=proveedores,
        q=q or "",
        categoria_sel=categoria or "",
        proveedor_sel=proveedor or "",
    )

@bp.route("/crear", methods=["POST"])
def create_product():
    try:
        nombre = request.form["nombre"].strip()
        precio = Decimal(request.form["precio"]
        )
        stock = int(request.form["stock"])
        categoria = request.form["categoria"].strip()
        proveedor = request.form["proveedor"].strip()

        if not nombre or precio < 0 or stock < 0:
            flash("Datos inválidos.", "danger")
            return redirect(url_for("products.list_products"))

        p = Product(
            nombre=nombre,
            precio=precio,
            stock=stock,
            categoria=categoria,
            proveedor=proveedor,
        )
        db.session.add(p)
        db.session.commit()
        flash("Producto creado correctamente.", "success")
    except (KeyError, InvalidOperation, ValueError):
        db.session.rollback()
        flash("Error al crear el producto. Revisa los datos.", "danger")
    return redirect(url_for("products.list_products"))

@bp.route("/<int:product_id>/editar", methods=["POST"])
def edit_product(product_id):
    p = Product.query.get_or_404(product_id)
    try:
        p.nombre = request.form["nombre"].strip()
        p.precio = Decimal(request.form["precio"])
        p.stock = int(request.form["stock"])
        p.categoria = request.form["categoria"].strip()
        p.proveedor = request.form["proveedor"].strip()

        if not p.nombre or p.precio < 0 or p.stock < 0:
            flash("Datos inválidos.", "danger")
            return redirect(url_for("products.list_products"))

        db.session.commit()
        flash("Producto actualizado.", "success")
    except (KeyError, InvalidOperation, ValueError):
        db.session.rollback()
        flash("Error al actualizar el producto.", "danger")
    return redirect(url_for("products.list_products"))

@bp.route("/<int:product_id>/eliminar", methods=["POST"])
def delete_product(product_id):
    p = Product.query.get_or_404(product_id)
    db.session.delete(p)
    db.session.commit()
    flash("Producto eliminado.", "warning")
    return redirect(url_for("products.list_products"))
