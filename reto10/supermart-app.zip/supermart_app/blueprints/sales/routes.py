from flask import Blueprint, render_template, request, redirect, url_for, flash
from decimal import Decimal
from ...extensions import db
from ...models import Product, Sale

bp = Blueprint("sales", __name__)

@bp.route("/", methods=["GET"])
def list_sales():
    sales = Sale.query.order_by(Sale.fecha.desc()).all()
    products = Product.query.order_by(Product.nombre.asc()).all()
    return render_template("ventas.html", sales=sales, products=products)

@bp.route("/nueva", methods=["POST"])
def create_sale():
    try:
        producto_id = int(request.form["producto_id"])
        cantidad = int(request.form["cantidad"])

        producto = Product.query.get_or_404(producto_id)

        if cantidad <= 0:
            flash("La cantidad debe ser mayor a 0.", "danger")
            return redirect(url_for("sales.list_sales"))

        if producto.stock < cantidad:
            flash("Stock insuficiente.", "danger")
            return redirect(url_for("sales.list_sales"))

        total = Decimal(producto.precio) * cantidad
        sale = Sale(producto_id=producto_id, cantidad=cantidad, total=total)
        producto.stock -= cantidad

        db.session.add(sale)
        db.session.commit()
        flash("Venta registrada exitosamente.", "success")
    except Exception:
        db.session.rollback()
        flash("Error registrando la venta.", "danger")
    return redirect(url_for("sales.list_sales"))
