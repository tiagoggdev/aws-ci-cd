from flask import Blueprint, render_template, jsonify
from sqlalchemy import func
from datetime import datetime, timedelta
from ...extensions import db
from ...models import Product, Sale

bp = Blueprint("reports", __name__)

@bp.route("/")
def reports_index():
    return render_template("reportes.html")


@bp.route("/api/ventas_por_categoria")
def api_ventas_por_categoria():
    data = (
        db.session.query(Product.categoria, func.sum(Sale.total))
        .join(Sale, Sale.producto_id == Product.id)
        .group_by(Product.categoria)
        .all()
    )
    labels = [d[0] for d in data]
    values = [float(d[1]) for d in data]
    return jsonify({"labels": labels, "values": values})

@bp.route("/api/ventas_por_dia")
def api_ventas_por_dia():
    days = 14
    today = datetime.utcnow().date()
    start_date = today - timedelta(days=days-1)

    result = (
        db.session.query(func.date(Sale.fecha).label("d"), func.sum(Sale.total))
        .filter(func.date(Sale.fecha) >= start_date)
        .group_by(func.date(Sale.fecha))
        .order_by(func.date(Sale.fecha))
        .all()
    )

    sales_map = {str(r[0]): float(r[1]) for r in result}
    labels, values = [], []
    for i in range(days):
        day = start_date + timedelta(days=i)
        labels.append(day.isoformat())
        values.append(sales_map.get(day.isoformat(), 0.0))

    return jsonify({"labels": labels, "values": values})

@bp.route("/api/ventas_por_proveedor")
def api_ventas_por_proveedor():
    data = (
        db.session.query(Product.proveedor, func.sum(Sale.total))
        .join(Sale, Sale.producto_id == Product.id)
        .group_by(Product.proveedor)
        .all()
    )
    labels = [d[0] for d in data]
    values = [float(d[1]) for d in data]
    return jsonify({"labels": labels, "values": values})
