from flask import Flask, render_template
from .config import Config
from .extensions import db
from .blueprints.dashboard.routes import bp as dashboard_bp
from .blueprints.products.routes import bp as products_bp
from .blueprints.sales.routes import bp as sales_bp
from .blueprints.reports.routes import bp as reports_bp
from .models import Product, Sale
import logging
from logging.handlers import RotatingFileHandler
import os

def create_app(config_class=Config):
    app = Flask(__name__, template_folder="../templates", static_folder="../static")
    app.config.from_object(config_class)

    # Extensiones
    db.init_app(app)

    # Blueprints
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(products_bp, url_prefix="/productos")
    app.register_blueprint(sales_bp, url_prefix="/ventas")
    app.register_blueprint(reports_bp, url_prefix="/reportes")

    # Errores
    register_error_handlers(app)

    # Logging
    setup_logging(app)

    # Crear tablas si no existen (útil para labs/POC)
    with app.app_context():
        db.create_all()

    @app.route("/health")
    def health():
        return {"status": "ok"}, 200

    return app

def register_error_handlers(app):
    @app.errorhandler(404)
    def not_found(e):
        return render_template("errors/404.html"), 404

    @app.errorhandler(500)
    def server_error(e):
        app.logger.exception("Error 500 no manejado")
        return render_template("errors/500.html"), 500

def setup_logging(app):
    log_dir = app.config.get("LOG_DIR", "./logs")
    os.makedirs(log_dir, exist_ok=True)
    file_handler = RotatingFileHandler(
        os.path.join(log_dir, "app.log"), maxBytes=1_000_000, backupCount=5
    )
    file_handler.setLevel(logging.INFO)
    formatter = logging.Formatter(
        "[%(asctime)s] %(levelname)s in %(module)s: %(message)s"
    )
    file_handler.setFormatter(formatter)
    app.logger.addHandler(file_handler)
    app.logger.setLevel(logging.INFO)
