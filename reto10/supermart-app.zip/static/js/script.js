document.addEventListener('DOMContentLoaded', () => {
  const input = document.querySelector('input[name="q"]');
  const table = document.getElementById('tablaProductos');
  if (!input || !table) return;

  input.addEventListener('keyup', () => {
    const term = input.value.toLowerCase();
    const rows = table.querySelectorAll('tbody tr');
    rows.forEach(r => {
      const text = r.innerText.toLowerCase();
      r.style.display = text.includes(term) ? '' : 'none';
    });
  });
});
