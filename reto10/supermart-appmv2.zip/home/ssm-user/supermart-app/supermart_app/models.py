from .extensions import db
from sqlalchemy import func
from datetime import datetime

class Product(db.Model):
    __tablename__ = "productos"
    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(120), nullable=False)
    precio = db.Column(db.Numeric(10, 2), nullable=False)
    stock = db.Column(db.Integer, nullable=False, default=0)
    categoria = db.Column(db.String(100), nullable=False)
    proveedor = db.Column(db.String(120), nullable=False)
    creado_en = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    ventas = db.relationship("Sale", backref="producto", lazy=True)

class Sale(db.Model):
    __tablename__ = "ventas"
    id = db.Column(db.Integer, primary_key=True)
    producto_id = db.Column(db.Integer, db.ForeignKey("productos.id"), nullable=False)
    cantidad = db.Column(db.Integer, nullable=False)
    total = db.Column(db.Numeric(10, 2), nullable=False)
    fecha = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)

    @staticmethod
    def total_vendido_hoy():
        today = datetime.utcnow().date()
        return db.session.query(func.coalesce(func.sum(Sale.total), 0)).filter(
            func.date(Sale.fecha) == today
        ).scalar()

    @staticmethod
    def cantidad_vendida_hoy():
        today = datetime.utcnow().date()
        return db.session.query(func.coalesce(func.sum(Sale.cantidad), 0)).filter(
            func.date(Sale.fecha) == today
        ).scalar()
