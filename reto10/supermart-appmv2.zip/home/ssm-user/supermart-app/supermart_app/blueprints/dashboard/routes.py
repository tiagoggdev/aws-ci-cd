from flask import Blueprint, render_template
from sqlalchemy import func
from ...extensions import db
from ...models import Product, Sale

bp = Blueprint("dashboard", __name__)

@bp.route("/")
def home():
    total_productos = Product.query.count()
    ventas_hoy_cantidad = Sale.cantidad_vendida_hoy()
    ingresos_hoy = Sale.total_vendido_hoy()
    low_stock = Product.query.filter(Product.stock < 10).order_by(Product.stock.asc()).limit(10).all()

    ventas_por_categoria = (
        db.session.query(Product.categoria, func.sum(Sale.total))
        .join(Sale, Sale.producto_id == Product.id)
        .group_by(Product.categoria)
        .all()
    )

    return render_template(
        "dashboard.html",
        total_productos=total_productos,
        ventas_hoy_cantidad=ventas_hoy_cantidad,
        ingresos_hoy=ingresos_hoy,
        low_stock=low_stock,
        ventas_por_categoria=ventas_por_categoria,
    )
