from flask import Flask, request, jsonify
import psycopg2
import os

app = Flask(__name__)

# Leer variables de entorno
DB_HOST = os.environ.get("DB_HOST")
DB_NAME = os.environ.get("DB_NAME")
DB_USER = os.environ.get("DB_USER")
DB_PASS = os.environ.get("DB_PASS")

@app.route("/")
def home():
    return "Aplicación Flask conectada a RDS"

@app.route("/agregar", methods=['POST'])
def agregar():
    data = request.get_json()
    nombre = data['nombre']
    conexion = psycopg2.connect(host=DB_HOST, dbname=DB_NAME, user=DB_USER, password=DB_PASS)
    cursor = conexion.cursor()
    cursor.execute("INSERT INTO personas (nombre) VALUES (%s);", (nombre,))
    conexion.commit()
    cursor.close()
    conexion.close()
    return jsonify({"mensaje": "Persona agregada"})

@app.route("/personas")
def listar():
    conexion = psycopg2.connect(host=DB_HOST, dbname=DB_NAME, user=DB_USER, password=DB_PASS)
    cursor = conexion.cursor()
    cursor.execute("SELECT * FROM personas;")
    resultados = cursor.fetchall()
    cursor.close()
    conexion.close()
    return jsonify(resultados)

application = app