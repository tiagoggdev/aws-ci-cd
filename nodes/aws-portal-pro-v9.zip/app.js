
const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const { Pool } = require('pg');

const app = express();
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static('public'));

const pool = new Pool({
  host: 'basedatosflask.cbd8cduyt8bf.us-east-1.rds.amazonaws.com',
  user: 'postgres',
  password: 'UnaClaveSegura123!',
  database: 'postgres',
  port: 5432
});

app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'views', 'index.html')));
app.get('/register', (req, res) => res.sendFile(path.join(__dirname, 'views', 'register.html')));
app.post('/register', async (req, res) => {
  const { nombre, correo } = req.body;
  try {
    await pool.query('INSERT INTO clientes(nombre, correo) VALUES($1, $2)', [nombre, correo]);
    res.sendFile(path.join(__dirname, 'views', 'success.html'));
  } catch (err) {
    console.error(err);
    res.send('<h2>Error al registrar cliente. Verifica consola.</h2>');
  }
});
app.get('/search', (req, res) => res.sendFile(path.join(__dirname, 'views', 'search.html')));
app.post('/search', async (req, res) => {
  const { correo } = req.body;
  try {
    const result = await pool.query('SELECT * FROM clientes WHERE correo = $1', [correo]);
    if (result.rows.length > 0) {
      res.send(`<h2>Cliente encontrado:</h2><p>Nombre: ${result.rows[0].nombre}</p>`);
    } else {
      res.send('<h2>No se encontró el cliente.</h2>');
    }
  } catch (err) {
    console.error(err);
    res.send('<h2>Error en la búsqueda.</h2>');
  }
});
app.listen(process.env.PORT || 3000, () => console.log("Servidor corriendo"));
